<?php
class conta{
    private $numero;
    private $banco;
    private $saldo;
    public function despositar(){
    }
    public function sacar(){

    }
}
?>