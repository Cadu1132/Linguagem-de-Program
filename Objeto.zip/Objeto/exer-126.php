<?php
class quadrado{
    private $lado;
    public function setLado($lado){
        $this ->lado = $lado;
    }
    public function calculaArea(){
        $resultado = $this->lado * $this ->lado;
        return $resultado;
    }
}
?>

<?php
class aeroporto{
    private $nome;
    private $cidade;
    public function getNome(){
        return $this ->nome;
    }
    public function setNome($nome){
        return $this = $nome;
    }
    public function getCidade(){
        return $this ->nome;
    }
    public function setCidade($cidade){
        return $this = $cidade;
    }
}

?>