<?php
class adulto {
    private $peso:
    public function engordar($quilos){
        $this ->peso += $quilos;
    }
    public function emagrecer($quilos){
        $this->peso -= $quilos;
    }

}
?>

<?php
class televisao{
    private $status;
    private $canal;
    private $volume;
    public function _construct(){
        $this -> status = false;
        $this -> canal = 3;
        $this -> volume = 10;
    }
    public function ligaDesliga(){
      $this -> status = !$this->status;
    }
    public function aumentaCanal(){
        $this -> canal++;
      }
      public function diminuiCanal(){
        $this -> canal--;
      }
      public function aumentaVolume(){
        $this -> volume++;
      }
      public function diminuiVolume(){
        $this -> volume--;
      }
      public function mostarCanal(){
        return $this -> canal;
      }
      public function mostrarVolume(){
        return $this -> canal;
      }
}
?>