
<html>
    <head>
        <title>Rêtangulo</title>
    </head>
    <body>
        <?php
        if (isset($_POST["botao"])){
            include_once("Retangulo.class.php");
            $retangulo = new Retangulo();
            $retangulo -> setLadoMaior($_POST["largura"]);
            $retangulo -> setLadoMenor($_POST["altura"]);
            $area = $retangulo ->calculaArea();
            echo "A área é:".$area;
        }
        else{
            ?>
            <from action="retangulo.php" method="post">
                Informe a largura : <input type="text" name="largura"><br>
                Informe a altura : <input type="text" name="altura"><br>
                <input type="submit" name="botao" value="Calcula Área">
        </from>
        <?php
        }
        ?>
    </body>
</html>

