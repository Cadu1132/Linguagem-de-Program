<html>
    <head>
        <title>Sequência</title>
    </head>
    <body>
        <?php
        if (isset($_POST["botao"])){
            include_once("Sequencia.class.php");
            $sequencia = new Sequencia();
            $sequencia -> setInicio($_POST["inicio"]);
            $sequencia -> setFim($_POST["fim"]);
            if($_POST["mostrar"] == "todos")
             $sequencia->exibirTodosNumeros();
            elseif($_POST["mostrar"] == "pares")
             $sequencia-> exibirPares();
            elseif($_POST["mostrar"] == "impares")
             $sequencia->exibirImpares(); 
        }
        else{
            ?>
            <from action="sequencia.php" method="post">
                Selecione o valor inicial:
                <select name ="inicio">
                <option value="1" selected>1 </option>;
                <?php
                for ($i = 2; $i <= 100; $i++){
                    echo'<option value= "'.$i.'">'.$i.'</option>';
                }
            ?>  
            </select>
            <select name="fim">
                <?php
                for ($i = 1; $i <= 99; $i++){
                    echo'<option value= "'.$i.'">'.$i.'</option>';
                }
                ?>
              <option value="100" selected>100 </option>
            </select>
            Mostar<br>
            <input type="radio" name="mostrar" value="todos" checkend>Todos<br>
            <input type="radio" name="mostrar" value="pares" >Apenas os Pares<br>
            <input type="radio" name="mostrar" value="impares" checkend>Apenas os Impares<br>
            <input type="submit" name="botao" value="Enviar">
            </from>
            <?php
        }
        ?>
    </body>
</html>